# Culture Concorde ️🎶
Discover incredible songs, carefully selected, crafted in a minimalist design.  A free player available on Mac OS X written in swift and also coming to iOS and Android. More info : http://www.cultureconcorde.com/




## Preview ✈️
![alt tag](https://github.com/PierreBresson/App-MacOS-Culture-Concorde/blob/master/mac%20app.jpg)




### Features
* 4 categories of music: Chillwave, Funky House, Deep & Tech, Mixtape

* Next/previous songs, play, pause with media keys (F7,F8,F9).

* Notification if an update is available





### What Next?
* iOS and Android version

* Improve design and create a visual identity

* Add more music & categories






### Do you want to help?
PR are welcome :)



### Wanna test the app?
Download app on the website : http://cultureconcorde.com
