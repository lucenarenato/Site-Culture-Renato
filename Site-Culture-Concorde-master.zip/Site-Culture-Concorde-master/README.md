# Culture Concorde ️🎶
Discover incredible songs, carefully selected, crafted in a minimalist design.  A free player available on [iOS](https://itunes.apple.com/us/app/culture-concorde/id1212137530?ls=1&mt=8) and [macOS](https://itunes.apple.com/us/app/culture-concorde/id1088330492?ls=1&mt=12) and also coming to Android. More info : http://www.cultureconcorde.com/



## Preview ✈️
![alt tag](https://github.com/PierreBresson/Site-Culture-Concorde/blob/master/mac%20app.jpg)




### Features
* 4 categories of music: Chillwave, Funky House, Deep & Tech, Mixtape (macOS only)

* Next/previous songs, play, pause with media keys (F7,F8,F9).

* Notification if an update is available





### What Next?
* Android version

* Add control center feature

* Add more music & categories






### Do you want to help?
PR are welcome :)



### Wanna test the app?
Download app on the website : http://cultureconcorde.com
